﻿namespace Zoo
{
    public class Raptile : Animal
    {
        public Raptile(string name) : base(name)
        {

        }
    }
}
