﻿using System;
using System.Collections.Generic;

namespace Generic_box_of_string
{
    class Program
    {
        static void Main(string[] args)
        {
            int rows = int.Parse(Console.ReadLine());
            List<Box<string>> boxLst = new List<Box<string>>();
            for (int i = 0; i < rows; i++)
            {
                boxLst.Add(new Box<string>(Console.ReadLine()));
            }
            foreach (var item in boxLst)
            {
                Console.WriteLine(item);
            }
        }
    }
}
