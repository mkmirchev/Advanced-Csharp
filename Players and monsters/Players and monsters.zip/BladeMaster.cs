﻿namespace Players_and_monsters
{
    public class BladeMaster : DarkKnight
    {
        public BladeMaster(string name, int lvl) : base(name, lvl)
        {
        }
    }
}
