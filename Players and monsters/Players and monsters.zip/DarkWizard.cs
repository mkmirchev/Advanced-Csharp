﻿namespace Players_and_monsters
{
    public class DarkWizard : Wizard
    {
        public DarkWizard(string name, int lvl) : base(name, lvl)
        {
        }
    }
}
