﻿namespace Players_and_monsters
{
    public class SoulMaster : DarkWizard
    {
        public SoulMaster(string name, int lvl) : base(name, lvl)
        {
        }
    }
}
