﻿namespace Players_and_monsters
{
    public class BladeKnight : DarkKnight
    {
        public BladeKnight(string name, int lvl) : base(name, lvl)
        {
        }
    }
}
