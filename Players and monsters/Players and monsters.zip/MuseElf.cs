﻿namespace Players_and_monsters
{
    public class MuseElf: Elf
    {
        public MuseElf(string name, int lvl): base(name,lvl)
        {

        }
    }
}
