﻿namespace Players_and_monsters
{
    public class Elf: Hero
    {
        public Elf(string name, int lvl): base(name,lvl)
        {

        }
    }
}
