﻿namespace Players_and_monsters
{
    public class Knight : Hero
    {
        public Knight(string name, int lvl) : base(name, lvl)
        {
        }
    }
}
