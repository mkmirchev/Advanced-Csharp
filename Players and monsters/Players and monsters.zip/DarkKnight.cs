﻿namespace Players_and_monsters
{
    public class DarkKnight : Knight
    {
        public DarkKnight(string name, int lvl) : base(name, lvl)
        {
        }
    }
}
