﻿namespace Players_and_monsters
{
    public class Wizard : Hero
    {
        public Wizard(string name, int lvl) : base(name, lvl)
        {
        }
    }
}
